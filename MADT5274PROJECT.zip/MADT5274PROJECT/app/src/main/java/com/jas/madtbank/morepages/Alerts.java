package com.jas.madtbank.morepages;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

import com.jas.madtbank.R;

public class Alerts extends AppCompatActivity {

    Switch transfer_switch,bills_switch;
    public SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alerts);

        sp = PreferenceManager.getDefaultSharedPreferences(getBaseContext());

        transfer_switch = findViewById(R.id.transfer_switch);
        bills_switch = findViewById(R.id.bills_switch);

        if(sp.getBoolean("transfer",false)){
            transfer_switch.setChecked(true);
        }else{
            transfer_switch.setChecked(false);
        }

        if(sp.getBoolean("bills",false)){
            bills_switch.setChecked(true);
        }else{
            bills_switch.setChecked(false);
        }

        transfer_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked){
                    sp.edit().putBoolean("transfer",true).apply();
                }else{
                    sp.edit().putBoolean("transfer",false).apply();
                }
            }
        });

        bills_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked){
                    sp.edit().putBoolean("bills",true).apply();
                }else{
                    sp.edit().putBoolean("bills",false).apply();
                }
            }
        });
    }

    public void gotitA(View v){
        finish();
    }
}
