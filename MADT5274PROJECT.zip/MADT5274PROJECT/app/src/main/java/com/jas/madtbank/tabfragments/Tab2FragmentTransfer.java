package com.jas.madtbank.tabfragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jas.madtbank.user.ClientOther;
import com.jas.madtbank.activities.LoginActivity;
import com.jas.madtbank.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;


public class Tab2FragmentTransfer extends Fragment {
    RadioGroup rg_accs;
    LinearLayout ll_btw,ll_other;
    Spinner spFrom,spTo,spinner1;
    int acc = 0;

    static public FirebaseDatabase databasee ;
    static public DatabaseReference myReff;
    ClientOther clientother;
    boolean flag = false;

    EditText amount_other,account_other;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_transfer, container, false);

        databasee = FirebaseDatabase.getInstance();
        myReff = databasee.getReference("cards");

        final RadioButton rb_btw = v.findViewById(R.id.rb_btw);
        final RadioButton rb_other = v.findViewById(R.id.rb_other);
        final EditText amount_between = v.findViewById(R.id.amount_between);

        amount_other = v.findViewById(R.id.amount_other);
        account_other = v.findViewById(R.id.account_other);

        spinner1 = v.findViewById(R.id.spinner1); // other account from
        rg_accs = v.findViewById(R.id.rg_accs);
        ll_other = v.findViewById(R.id.ll_other);
        ll_btw = v.findViewById(R.id.ll_btw);

        spFrom = v.findViewById(R.id.spinnerFrom); // between account from
        spTo = v.findViewById(R.id.spinnerTo); // between account to

// (2) create a simple static list of strings
        List<String> spinnerArray = new ArrayList<>();
        spinnerArray.add("Select Account Type");
        spinnerArray.add("Checking");
        spinnerArray.add("Savings");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_spinner_item,
                spinnerArray
        );
        spinner1.setAdapter(adapter);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_spinner_item,
                spinnerArray
        );
        spTo.setAdapter(adapter1);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_spinner_item,
                spinnerArray
        );
        spFrom.setAdapter(adapter2);


        rg_accs.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                if(radioGroup.getCheckedRadioButtonId() == R.id.rb_btw){
                    ll_other.setVisibility(View.GONE);
                    ll_btw.setVisibility(View.VISIBLE);
                }else{
                    ll_other.setVisibility(View.VISIBLE);
                    ll_btw.setVisibility(View.GONE);
                }
            }
        });

        Button transfer = v.findViewById(R.id.btn_transfer);
        transfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(rb_btw.isChecked()){

                    if(spFrom.getSelectedItem().toString().equals("Select Account Type") || spTo.getSelectedItem().toString().equals("Select Account Type")){
                        LoginActivity.showalert(getActivity(),"Error","Select accounts to transfer.");
                        return;
                    }

                    if(spFrom.getSelectedItem().toString().equals(spTo.getSelectedItem().toString())){
                        LoginActivity.showalert(getActivity(),"Error","You can't transfer to same accounts.");
                        return;
                    }

                    if(amount_between.getText().toString().equals("") || amount_between.getText().toString() == null){
                        LoginActivity.showalert(getActivity(),"Error","Amount can't be empty.");
                        return;
                    }

                    final Double amount = Double.valueOf(amount_between.getText().toString());

                    if(amount <= 0){
                        LoginActivity.showalert(getActivity(),"Error","Amount should be more than zero.");
                        return;
                    }else{

                        Double bankbalance = 0.0;

                        if(spFrom.getSelectedItem().toString().equals("Checking")){
                            bankbalance = LoginActivity.client.getChecking_balance();
                        }else if(spFrom.getSelectedItem().toString().equals("Savings")){
                            bankbalance = LoginActivity.client.getSaving_balance();
                        }

                        if(bankbalance < amount){
                            LoginActivity.showalert(getActivity(),"Error","You account don't have sufficient balance to transfer.");
                            return;
                        }else{

                            if(spTo.getSelectedItem().toString().equals("Checking")){
                                LoginActivity.client.setChecking_balance(LoginActivity.client.getChecking_balance() + amount);
                                LoginActivity.client.setSaving_balance(LoginActivity.client.getSaving_balance() - amount);

                                LoginActivity.myRef.child("checking_balance").setValue(LoginActivity.client.getChecking_balance());
                                LoginActivity.myRef.child("saving_balance").setValue(LoginActivity.client.getSaving_balance());

                                Date date = Calendar.getInstance().getTime();
                                DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                                String today = formatter.format(date);

                                String trans = today+" From OWN Savings "+amount+"cr%"+LoginActivity.client.getChecking_transactions();
                                LoginActivity.client.setChecking_transactions(trans);
                                LoginActivity.myRef.child("checking_transactions").setValue(trans);

                                trans = today+" To OWN Checkings "+amount+"db%"+LoginActivity.client.getSaving_transactions();
                                LoginActivity.client.setSaving_transactions(trans);
                                LoginActivity.myRef.child("saving_transactions").setValue(trans);

                            }else if(spTo.getSelectedItem().toString().equals("Savings")){
                                LoginActivity.client.setSaving_balance(LoginActivity.client.getSaving_balance() + amount);
                                LoginActivity.client.setChecking_balance(LoginActivity.client.getChecking_balance() - amount);

                                LoginActivity.myRef.child("checking_balance").setValue(LoginActivity.client.getChecking_balance());
                                LoginActivity.myRef.child("saving_balance").setValue(LoginActivity.client.getSaving_balance());

                                Date date = Calendar.getInstance().getTime();
                                DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                                String today = formatter.format(date);

                                String trans = today+" To OWN Savings "+amount+"db%"+LoginActivity.client.getChecking_transactions();
                                LoginActivity.client.setChecking_transactions(trans);
                                LoginActivity.myRef.child("checking_transactions").setValue(trans);

                                trans = today+"  From OWN Checkings  "+amount+"cr%"+LoginActivity.client.getSaving_transactions();
                                LoginActivity.client.setSaving_transactions(trans);
                                LoginActivity.myRef.child("saving_transactions").setValue(trans);

                            }

                            UUID uuid = UUID.randomUUID();
                            LoginActivity.showalert(getActivity(),"Success","Amount transferred successfully."+ "\nReference no: " + uuid.toString());

                            if(LoginActivity.sp.getBoolean("transfer",false)){
                                LoginActivity.sendNotification(getActivity(),"Transfer Own Account","Amount transferred successfully."+ "\nReference no: " + uuid.toString());
                            }

                            spFrom.setSelection(0);
                            spTo.setSelection(0);
                            amount_between.setText("");

//                            LoginActivity.myRef.addValueEventListener(new ValueEventListener() {
//                                @Override
//                                public void onDataChange(DataSnapshot dataSnapshot) {
//                                }
//
//                                @Override
//                                public void onCancelled(DatabaseError databaseError) {
//
//                                }
//                            });

                        }

                    }


                } else if(rb_other.isChecked()){

                    if(spinner1.getSelectedItem().toString().equals("Select Account Type")){
                        LoginActivity.showalert(getActivity(),"Error","Select accounts to transfer.");
                        return;
                    }

                    if(amount_other.getText().toString().equals("") || amount_other.getText().toString() == null){
                        LoginActivity.showalert(getActivity(),"Error","Amount can't be empty.");
                        return;
                    }

                    if(account_other.getText().toString().equals("") || account_other.getText().toString() == null){
                        LoginActivity.showalert(getActivity(),"Error","Account Number can't be empty.");
                        return;
                    }

                    if(account_other.getText().toString().equals(LoginActivity.client.getChecking_account()) || account_other.getText().toString().equals(LoginActivity.client.getSaving_account())){
                        LoginActivity.showalert(getActivity(),"Error","Can't transfer to own account number from own accounts!");
                        return;
                    }

                    final Double amount = Double.valueOf(amount_other.getText().toString());

                    if(amount <= 0){
                        LoginActivity.showalert(getActivity(),"Error","Amount should be more than zero.");
                        return;
                    }else{

                        Double bankbalance = 0.0;

                        if(spinner1.getSelectedItem().toString().equals("Checking")){
                            bankbalance = LoginActivity.client.getChecking_balance();
                        }else if(spinner1.getSelectedItem().toString().equals("Savings")){
                            bankbalance = LoginActivity.client.getSaving_balance();
                        }

                        if(bankbalance < amount){
                            LoginActivity.showalert(getActivity(),"Error","You account don't have sufficient balance to transfer.");
                            return;
                        }else{

                            Log.v("Transfer","All OK");
                            // all ok now find the accountno. to transfer

                            myReff = databasee.getReference("cards");

                            myReff.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    // This method is called once with the initial value and again
                                    // whenever data at this location is updated.

                                    for(DataSnapshot postSnapshot: dataSnapshot.getChildren()){

                                        String account = postSnapshot.getKey();
                                        Log.d(LoginActivity.TAG, "Account is: " + account);

                                        if(!account.contains(",")){
                                            continue;
                                        }

                                        String[] separated = account.split(",");
                                        String checkingother = separated[1];
                                        String savingsother = separated[2];

                                        if(checkingother.equals(account_other.getText().toString())){
                                            acc = 1;
                                            flag = true;

                                            Double checking_balance = dataSnapshot.child(account).child("checking_balance").getValue(double.class);
                                            Double saving_balance = dataSnapshot.child(account).child("saving_balance").getValue(double.class);

                                            String checking_transactions = dataSnapshot.child(account).child("checking_transactions").getValue(String.class);
                                            String saving_transactions = dataSnapshot.child(account).child("saving_transactions").getValue(String.class);

                                            clientother = new ClientOther(account,checkingother,savingsother,checking_transactions,saving_transactions,checking_balance,saving_balance);

                                            break;
                                        } else if(savingsother.equals(account_other.getText().toString())){
                                            acc = 2;
                                            flag = true;

                                            Double checking_balance = dataSnapshot.child(account).child("checking_balance").getValue(double.class);
                                            Double saving_balance = dataSnapshot.child(account).child("saving_balance").getValue(double.class);

                                            String checking_transactions = dataSnapshot.child(account).child("checking_transactions").getValue(String.class);
                                            String saving_transactions = dataSnapshot.child(account).child("saving_transactions").getValue(String.class);

                                            clientother = new ClientOther(account,checkingother,savingsother,checking_transactions,saving_transactions,checking_balance,saving_balance);

                                            break;
                                        }

                                    }

                                    myReff.removeEventListener(this);

                                    if(flag){
                                        dowork(amount);
                                    }else{
                                        LoginActivity.showalert(getActivity(),"Error","Account does not exist!");
                                    }

                                }

                                @Override
                                public void onCancelled(DatabaseError error) {
                                    // Failed to read value
                                    Log.w(LoginActivity.TAG, "Failed to read value.", error.toException());
                                }
                            });

                        }
                    }

                }



            }
        });
        return  v;
    }

    private void dowork(double amount){

        Date date = Calendar.getInstance().getTime();
        DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        String today = formatter.format(date);

        //ISSUE HERE

        if(acc == 1){ // checkings

            String from_acc = "";
            if(spinner1.getSelectedItem().toString().equals("Checking")){
                from_acc = LoginActivity.client.getChecking_account();
            }else if(spinner1.getSelectedItem().toString().equals("Savings")){
                from_acc = LoginActivity.client.getSaving_account();
            }

            String trans;
            trans = today+" FROM'"+ from_acc+"' "+amount+"cr%"+clientother.getChecking_transactions();

            String client_acc = clientother.getFullacc();
            myReff.child(client_acc).child("checking_balance").setValue((clientother.getChecking_balance() + amount));
            myReff.child(client_acc).child("checking_transactions").setValue(trans);

            ////////////////////////////

            if(spinner1.getSelectedItem().toString().equals("Checking")){

                LoginActivity.client.setChecking_balance(LoginActivity.client.getChecking_balance() - amount);
                myReff.child(LoginActivity.client.getFullacc()).child("checking_balance").setValue(LoginActivity.client.getChecking_balance());

                String to_acc = account_other.getText().toString();
                trans = today+" TO'"+to_acc+"' "+amount+"db%"+LoginActivity.client.getChecking_transactions();
                LoginActivity.client.setChecking_transactions(trans);
                myReff.child(LoginActivity.client.getFullacc()).child("checking_transactions").setValue(trans);

            }else if(spinner1.getSelectedItem().toString().equals("Savings")){

                LoginActivity.client.setSaving_balance(LoginActivity.client.getSaving_balance() - amount);
                myReff.child(LoginActivity.client.getFullacc()).child("saving_balance").setValue(LoginActivity.client.getSaving_balance());

                String to_acc = account_other.getText().toString();
                trans = today+" TO'"+to_acc+"' "+amount+"db%"+LoginActivity.client.getSaving_transactions();
                LoginActivity.client.setSaving_transactions(trans);
                myReff.child(LoginActivity.client.getFullacc()).child("saving_transactions").setValue(trans);
            }

        } else if(acc == 2){ // savings

            String from_acc = "";
            if(spinner1.getSelectedItem().toString().equals("Checking")){
                from_acc = LoginActivity.client.getChecking_account();
            }else if(spinner1.getSelectedItem().toString().equals("Savings")){
                from_acc = LoginActivity.client.getSaving_account();
            }

            String trans;
            trans = today+" FROM'"+ from_acc+"' "+amount+"cr%"+clientother.getSaving_transactions();

            String client_acc = clientother.getFullacc();
            myReff.child(client_acc).child("saving_balance").setValue((clientother.getSaving_balance() + amount));
            myReff.child(client_acc).child("saving_transactions").setValue(trans);

            ////////////////////////////

            if(spinner1.getSelectedItem().toString().equals("Checking")){

                LoginActivity.client.setChecking_balance(LoginActivity.client.getChecking_balance() - amount);
                myReff.child(LoginActivity.client.getFullacc()).child("checking_balance").setValue(LoginActivity.client.getChecking_balance());

                String to_acc = account_other.getText().toString();
                trans = today+" TO'"+to_acc+"' "+amount+"db%"+LoginActivity.client.getChecking_transactions();
                LoginActivity.client.setChecking_transactions(trans);
                myReff.child(LoginActivity.client.getFullacc()).child("checking_transactions").setValue(trans);

            }else if(spinner1.getSelectedItem().toString().equals("Savings")){

                LoginActivity.client.setSaving_balance(LoginActivity.client.getSaving_balance() - amount);
                myReff.child(LoginActivity.client.getFullacc()).child("saving_balance").setValue(LoginActivity.client.getSaving_balance());

                String to_acc = account_other.getText().toString();
                trans = today+" TO'"+to_acc+"' "+amount+"db%"+LoginActivity.client.getSaving_transactions();
                LoginActivity.client.setSaving_transactions(trans);
                myReff.child(LoginActivity.client.getFullacc()).child("saving_transactions").setValue(trans);
            }

        }

        spinner1.setSelection(0);
        account_other.setText("");
        amount_other.setText("");
        flag = false;

        UUID uuid = UUID.randomUUID();
        LoginActivity.showalert(getActivity(), "Success", "Amount transferred successfully." + "\nReference no: " + uuid.toString());

        if(LoginActivity.sp.getBoolean("transfer",false)){
            LoginActivity.sendNotification(getActivity(),"Transfer Other Account","Amount transferred successfully."+ "\nReference no: " + uuid.toString());
        }



//            myRefff.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(DataSnapshot dataSnapshot) {
//                }
//
//                @Override
//                public void onCancelled(DatabaseError databaseError) {
//
//                }
//            });
        
    }
}
