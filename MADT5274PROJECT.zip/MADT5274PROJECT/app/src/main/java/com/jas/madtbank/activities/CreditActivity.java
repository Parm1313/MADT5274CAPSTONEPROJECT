package com.jas.madtbank.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jas.madtbank.R;

import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class CreditActivity extends AppCompatActivity {

    TextView credit_acc_statement_bal,credit_acc_status,credit_trans;

    ArrayList<String> allTrans = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit);

        TextView credit_bal = findViewById(R.id.credit_bal);
        //TextView credit_acc = findViewById(R.id.credit_acc);

        TextView credit_lim = findViewById(R.id.credit_lim);
        TextView credit_avai = findViewById(R.id.credit_avai);

        credit_bal.setText("$"+decimalFormat(LoginActivity.client.getCredit_balance()));
        //credit_acc.setText(LoginActivity.client.getCredit_account());

        credit_lim.setText("$"+decimalFormat(LoginActivity.client.getCredit_limit()));
        credit_avai.setText("$"+ decimalFormat(LoginActivity.client.getCredit_limit() - LoginActivity.client.getCredit_balance()));

        credit_trans = findViewById(R.id.credit_trans);
        final String trans = LoginActivity.client.getCredit_transactions();
        credit_trans.setText(trans.replaceAll("%","\n\n"));

        String[] separated = trans.split("%");

        for(int i=0;i < separated.length;i++){
            allTrans.add(separated[i]);
        }

        SearchView searchView = findViewById(R.id.searchview);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                String data = "";

                for(int i =0; i< allTrans.size();i++){
                    if(allTrans.get(i).toLowerCase(Locale.CANADA).contains(newText.toLowerCase(Locale.CANADA))){
                        data = data +"\n\n" + allTrans.get(i);
                    }
                }

                if(newText.equals("")){
                    data = trans.replaceAll("%","\n\n");
                }
                credit_trans.setText(data);
                return true;
            }
        });

        credit_acc_statement_bal = findViewById(R.id.credit_acc_statement_bal);
        TextView credit_acc_due = findViewById(R.id.credit_acc_due);
        credit_acc_status = findViewById(R.id.credit_acc_status);

        String credit_statement = LoginActivity.client.getCredit_statement();
        String[] separated1 = credit_statement.split("%");
        String credit_acc_statement_bal1 = separated1[0];
        String credit_acc_due1 = separated1[1];
        String credit_acc_status1 = separated1[2];

        credit_acc_statement_bal.setText(credit_acc_statement_bal1);
        credit_acc_due.setText(credit_acc_due1);
        credit_acc_status.setText(credit_acc_status1);

    }

    public double decimalFormat(double dd){
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.FLOOR);
        double result = Double.parseDouble(df.format(dd));
        return result;
    }

    public void makePaymentCredit(View v){

        TextView credit_acc_status = findViewById(R.id.credit_acc_status);
        if(credit_acc_status.getText().toString().equals("PAID")){
            Toast.makeText(this, "You already PAID the current statement!\nWait for the next statement!", Toast.LENGTH_SHORT).show();
        }else{

            Double amount = Double.valueOf(credit_acc_statement_bal.getText().toString());

            if(amount <= 0){
                LoginActivity.showalert(this,"Error","Amount should be more than zero.");
                return;
            }else{

                if(LoginActivity.client.getChecking_balance() < amount){
                    LoginActivity.showalert(this,"Error","You checking account don't have sufficient balance to pay bill.");
                    return;
                }else{

                    LoginActivity.client.setChecking_balance(LoginActivity.client.getChecking_balance() - amount);

                    LoginActivity.myRef.child("checking_balance").setValue(LoginActivity.client.getChecking_balance());

                    Date date = Calendar.getInstance().getTime();
                    DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                    String today = formatter.format(date);

                    String trans = today+" BILL OWN Credit ACC'"+ LoginActivity.client.getCredit_account()+"' "+amount+"db%"+LoginActivity.client.getChecking_transactions();
                    LoginActivity.client.setChecking_transactions(trans);
                    LoginActivity.myRef.child("checking_transactions").setValue(trans);

                    trans = today+" BILL OWN Credit ACC'"+ LoginActivity.client.getCredit_account()+"' "+amount+"db%"+LoginActivity.client.getCredit_transactions();
                    LoginActivity.client.setCredit_transactions(trans);
                    LoginActivity.myRef.child("credit_transactions").setValue(trans);

                    /////
                    credit_acc_status.setText("PAID");
                    String cre_stat = LoginActivity.client.getCredit_statement().replace("UNPAID","PAID");
                    LoginActivity.client.setCredit_statement(cre_stat);
                    LoginActivity.myRef.child("credit_statement").setValue(cre_stat);

                    ////

                    trans = LoginActivity.client.getCredit_transactions();
                    credit_trans.setText(trans.replaceAll("%","\n"));

                    UUID uuid = UUID.randomUUID();

                    LoginActivity.showalert(this, "Receipt", "Bill Paid Successfully for credit account no: " + LoginActivity.client.getCredit_account() + "\nReference no: " + uuid.toString());

                }
            }
        }

    }
}
