package com.jas.madtbank.user;

public class Client {

    private String fullacc,name,dob,gender,email,address,checking_account,saving_account,credit_account,checking_transactions,saving_transactions,credit_transactions,credit_statement,pass;
    private double checking_balance,saving_balance,credit_balance,credit_limit;
    private long phone;

    public String getCredit_account() {
        return credit_account;
    }

    public void setCredit_account(String credit_account) {
        this.credit_account = credit_account;
    }

    public String getCredit_transactions() {
        return credit_transactions;
    }

    public void setCredit_transactions(String credit_transactions) {
        this.credit_transactions = credit_transactions;
    }

    public double getCredit_balance() {
        return credit_balance;
    }

    public void setCredit_balance(double credit_balance) {
        this.credit_balance = credit_balance;
    }

    public double getCredit_limit() {
        return credit_limit;
    }

    public void setCredit_limit(double credit_limit) {
        this.credit_limit = credit_limit;
    }

    public String getCredit_statement() {
        return credit_statement;
    }

    public void setCredit_statement(String credit_statement) {
        this.credit_statement = credit_statement;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public Client(String fullacc1, String name1, String dob1, String gender1, String email1, long phone1, String address1, String checking_account1, String saving_account1, String checking_transactions1, String saving_transactions1, double checking_balance1, double saving_balance1, String credit_account1, String credit_transactions1, double credit_balance1, double credit_limit1, String credit_statement1, String pass1){
        fullacc = fullacc1;
        name = name1;
        dob = dob1;
        gender = gender1;
        email = email1;
        phone = phone1;
        address = address1;
        checking_account = checking_account1;
        saving_account = saving_account1;
        checking_transactions = checking_transactions1;
        saving_transactions = saving_transactions1;
        checking_balance = checking_balance1;
        saving_balance = saving_balance1;
        credit_account = credit_account1;
        credit_balance = credit_balance1;
        credit_limit = credit_limit1;
        credit_transactions = credit_transactions1;
        credit_statement = credit_statement1;
        pass = pass1;
    }

    public String getFullacc() {
        return fullacc;
    }

    public void setFullacc(String fullacc) {
        this.fullacc = fullacc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getChecking_account() {
        return checking_account;
    }

    public void setChecking_account(String checking_account) {
        this.checking_account = checking_account;
    }

    public String getSaving_account() {
        return saving_account;
    }

    public void setSaving_account(String saving_account) {
        this.saving_account = saving_account;
    }

    public String getChecking_transactions() {
        return checking_transactions;
    }

    public void setChecking_transactions(String checking_transactions) {
        this.checking_transactions = checking_transactions;
    }

    public String getSaving_transactions() {
        return saving_transactions;
    }

    public void setSaving_transactions(String saving_transactions) {
        this.saving_transactions = saving_transactions;
    }

    public double getChecking_balance() {
        return checking_balance;
    }

    public void setChecking_balance(double checking_balance) {
        this.checking_balance = checking_balance;
    }

    public double getSaving_balance() {
        return saving_balance;
    }

    public void setSaving_balance(double saving_balance) {
        this.saving_balance = saving_balance;
    }

    public long getPhone() {
        return phone;
    }

    public void setPhone(long phone) {
        this.phone = phone;
    }



}
