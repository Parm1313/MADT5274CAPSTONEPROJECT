package com.jas.madtbank.tabfragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.jas.madtbank.activities.LoginActivity;
import com.jas.madtbank.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class Tab4FragmentProfile extends Fragment {

    private boolean edit_pressed = false;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_profile, container, false);

        TextView name = v.findViewById(R.id.name);
        name.setText(LoginActivity.client.getName());

        TextView gender = v.findViewById(R.id.gender);
        gender.setText(LoginActivity.client.getGender());

        CircleImageView civ = v.findViewById(R.id.profile_image);

        if(LoginActivity.client.getGender().equals("Male")){
            civ.setImageResource(R.drawable.boy);
        }else if(LoginActivity.client.getGender().equals("Female")){
            civ.setImageResource(R.drawable.girl);
        }

        TextView dob = v.findViewById(R.id.dob);
        dob.setText(LoginActivity.client.getDob());

        final EditText email = v.findViewById(R.id.email);
        email.setText(LoginActivity.client.getEmail());
        email.setEnabled(false);

        final EditText phone = v.findViewById(R.id.phone);
        phone.setText(""+LoginActivity.client.getPhone());
        phone.setEnabled(false);

        final EditText address = v.findViewById(R.id.address);
        address.setText(LoginActivity.client.getAddress().replaceAll(",","\n"));
        address.setEnabled(false);

        Button btn_edit = v.findViewById(R.id.btn_edit);
        btn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(edit_pressed){
                    edit_pressed = false;
                    email.setEnabled(false);
                    phone.setEnabled(false);
                    address.setEnabled(false);
                }else{
                    edit_pressed = true;
                    email.setEnabled(true);
                    phone.setEnabled(true);
                    address.setEnabled(true);
                }

            }
        });

        Button btn_save = v.findViewById(R.id.btn_save);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(edit_pressed){
                    edit_pressed = false;
                }else{
                    Toast.makeText(getActivity(), "Press EDIT to enable editing!", Toast.LENGTH_SHORT).show();
                    return;
                }

                email.setEnabled(false);
                phone.setEnabled(false);
                address.setEnabled(false);

                Toast.makeText(getActivity(), "Saved!", Toast.LENGTH_SHORT).show();

                String email_ = email.getText().toString();
                String phone_ = phone.getText().toString();
                String address_ = address.getText().toString();

                LoginActivity.client.setEmail(email_);
                LoginActivity.myRef.child("email").setValue(email_);

                long phone__ = Long.parseLong(phone_);
                LoginActivity.client.setPhone(phone__);
                LoginActivity.myRef.child("phone").setValue(phone__);

                LoginActivity.client.setAddress(address_);
                LoginActivity.myRef.child("address").setValue(address_);

//                LoginActivity.myRef.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//
//                    }
//                });

            }
        });

        return v;
    }

}