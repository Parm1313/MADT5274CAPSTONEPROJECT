package com.jas.madtbank.activities;

import android.os.Bundle;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.jas.madtbank.R;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Locale;

public class SavingActivity extends AppCompatActivity {

    ArrayList<String> allTrans = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saving);

        TextView saving_bal = findViewById(R.id.saving_bal);
        TextView saving_acc = findViewById(R.id.saving_acc);

        saving_bal.setText("$"+decimalFormat(LoginActivity.client.getSaving_balance()));
        saving_acc.setText(LoginActivity.client.getSaving_account());

        final TextView saving_trans = findViewById(R.id.saving_trans);
        final String trans = LoginActivity.client.getSaving_transactions();
        saving_trans.setText(trans.replaceAll("%","\n\n"));

        String[] separated = trans.split("%");

        for(int i=0;i < separated.length;i++){
            allTrans.add(separated[i]);
        }

        SearchView searchView = findViewById(R.id.searchview);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                String data = "";

                for(int i =0; i< allTrans.size();i++){
                    if(allTrans.get(i).toLowerCase(Locale.CANADA).contains(newText.toLowerCase(Locale.CANADA))){
                        data = data +"\n\n" + allTrans.get(i);
                    }
                }

                if(newText.equals("")){
                    data = trans.replaceAll("%","\n\n");
                }
                saving_trans.setText(data);
                return true;
            }
        });
    }

    public double decimalFormat(double dd){
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.FLOOR);
        double result = Double.parseDouble(df.format(dd));
        return result;
    }
}
