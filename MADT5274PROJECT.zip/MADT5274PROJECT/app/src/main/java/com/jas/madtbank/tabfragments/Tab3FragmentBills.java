package com.jas.madtbank.tabfragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.fragment.app.Fragment;

import com.jas.madtbank.activities.LoginActivity;
import com.jas.madtbank.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class Tab3FragmentBills extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_bills, container, false);

        final Spinner spinner1 = v.findViewById(R.id.spinner1);

// (2) create a simple static list of strings
        List<String> spinnerArray = new ArrayList<>();
        spinnerArray.add("Select Bill Type");
        spinnerArray.add("Hydro");
        spinnerArray.add("Water");
        spinnerArray.add("Gas");
        spinnerArray.add("Phone");

// (3) create an adapter from the list
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_spinner_item,
                spinnerArray
        );

//adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

// (4) set the adapter on the spinner
        spinner1.setAdapter(adapter);

        final EditText bill_amt = v.findViewById(R.id.bill_amt);
        final EditText bill_acc = v.findViewById(R.id.bill_acc);
        Button btn_pay = v.findViewById(R.id.btn_pay);
        btn_pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(spinner1.getSelectedItem().equals("Select Bill Type")){
                    LoginActivity.showalert(getActivity(),"Error","Select any bill provider first to proceed.");
                    return;
                }else{

                    if(bill_acc.getText().toString().length() < 3){
                        LoginActivity.showalert(getActivity(),"Error","Enter the right account number.");
                        return;
                    }else {

                        if(!bill_amt.getText().toString().equals("") && bill_amt.getText().toString()!= null){


                            Double amount = Double.valueOf(bill_amt.getText().toString());

                            if(amount <= 0){
                                LoginActivity.showalert(getActivity(),"Error","Amount should be more than zero.");
                                return;
                            }else{

                                if(LoginActivity.client.getChecking_balance() < amount){
                                    LoginActivity.showalert(getActivity(),"Error","You account don't have sufficient balance to pay bill.");
                                    return;
                                }else{

                                    // all ok

                                    LoginActivity.client.setChecking_balance(LoginActivity.client.getChecking_balance() - amount);

                                    LoginActivity.myRef.child("checking_balance").setValue(LoginActivity.client.getChecking_balance());

                                    Date date = Calendar.getInstance().getTime();
                                    DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                                    String today = formatter.format(date);

                                    String trans = today+" "+spinner1.getSelectedItem().toString().toUpperCase(Locale.US)+" BILL ACC'"+ bill_acc.getText().toString()+"' "+amount+"db%"+LoginActivity.client.getChecking_transactions();
                                    LoginActivity.client.setChecking_transactions(trans);
                                    LoginActivity.myRef.child("checking_transactions").setValue(trans);

                                    UUID uuid = UUID.randomUUID();

                                    LoginActivity.showalert(getActivity(), "Receipt", "Bill Paid Successfully for account no: " + bill_acc.getText().toString() + "\nReference no: " + uuid.toString());

                                    if(LoginActivity.sp.getBoolean("bills",false)){
                                        LoginActivity.sendNotification(getActivity(),"Bill Payment","Bill Paid Successfully for account no: " + bill_acc.getText().toString() + "\nReference no: " + uuid.toString());
                                    }

                                    spinner1.setSelection(0);
                                    bill_acc.setText("");
                                    bill_amt.setText("");

//                                    LoginActivity.myRef.addValueEventListener(new ValueEventListener() {
//                                        @Override
//                                        public void onDataChange(DataSnapshot dataSnapshot) {
//                                        }
//
//                                        @Override
//                                        public void onCancelled(DatabaseError databaseError) {
//
//                                        }
//                                    });


                                }

                            }

                        }else{
                            LoginActivity.showalert(getActivity(),"Error","Amount can't be empty.");
                            return;
                        }

                    }

                }

            }
        });

        return v;
    }

}