package com.jas.madtbank.tabfragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.jas.madtbank.morepages.Alerts;
import com.jas.madtbank.morepages.ChangePassword;
import com.jas.madtbank.morepages.Contact;
import com.jas.madtbank.morepages.Fingerprint;
import com.jas.madtbank.morepages.Security;
import com.jas.madtbank.R;


public class Tab5FragmentMore extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_more, container, false);


        Button btn_change_pass = v.findViewById(R.id.btn_change_pass);
        btn_change_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), ChangePassword.class);
                startActivity(i);
            }
        });

        Button btn_fingerprint = v.findViewById(R.id.btn_fingerprint);
        btn_fingerprint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), Fingerprint.class);
                startActivity(i);
            }
        });

        Button btn_alerts = v.findViewById(R.id.btn_alerts);
        btn_alerts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), Alerts.class);
                startActivity(i);
            }
        });

        Button btn_security = v.findViewById(R.id.btn_security);
        btn_security.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), Security.class);
                startActivity(i);
            }
        });

        Button btn_contact = v.findViewById(R.id.btn_contact);
        btn_contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), Contact.class);
                startActivity(i);
            }
        });

        return v;
    }

}