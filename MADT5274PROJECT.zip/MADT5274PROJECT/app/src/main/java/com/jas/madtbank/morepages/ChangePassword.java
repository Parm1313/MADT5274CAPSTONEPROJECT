package com.jas.madtbank.morepages;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jas.madtbank.activities.LoginActivity;
import com.jas.madtbank.R;

public class ChangePassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
    }

    public void changePasswordCancel(View v){
        finish();
    }

    public void changePassword(View v){

        EditText current_pass = findViewById(R.id.current_pass);
        EditText new_pass = findViewById(R.id.new_pass);
        EditText confirm_pass = findViewById(R.id.confirm_pass);

        if(current_pass.getText().toString().equals(LoginActivity.client.getPass())){

            if(new_pass.getText().toString().equals(confirm_pass.getText().toString())){

                LoginActivity.client.setPass(new_pass.getText().toString());
                LoginActivity.myRef.child("password").setValue(new_pass.getText().toString());

                current_pass.setText("");
                new_pass.setText("");
                confirm_pass.setText("");

                Toast.makeText(this, "Password changed successfully!", Toast.LENGTH_SHORT).show();
            }else{
                LoginActivity.showalert(this,"Error","New password and Confirm password doesn't match, Try again!");
            }

        }else{
            LoginActivity.showalert(this,"Error","Current password is wrong, please re-enter and Try again!");
        }

    }
}
