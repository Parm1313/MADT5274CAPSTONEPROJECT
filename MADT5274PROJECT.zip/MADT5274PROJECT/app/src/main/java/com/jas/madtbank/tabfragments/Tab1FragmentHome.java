package com.jas.madtbank.tabfragments;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.jas.madtbank.R;
import com.jas.madtbank.activities.CheckingActivity;
import com.jas.madtbank.activities.CreditActivity;
import com.jas.madtbank.activities.LoginActivity;
import com.jas.madtbank.activities.SavingActivity;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Tab1FragmentHome extends Fragment {
    TextView tv_checking,tv_saving,tv_credit,tv_total,homename,checking,saving,credit;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.activity_home, container, false);

        final TextView animatedText = v.findViewById(R.id.first);

        final ValueAnimator animator = ValueAnimator.ofFloat(-1.0f, 1.0f);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.setDuration(12000L);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                final float progress = (float) animation.getAnimatedValue();
                final float width = animatedText.getWidth();
                final float translationX = width * progress;
                animatedText.setTranslationX(translationX);
            }
        });
        animator.start();

        TextView checking_name = v.findViewById(R.id.checking_name);
        TextView saving_name = v.findViewById(R.id.saving_name);
        TextView credit_name = v.findViewById(R.id.credit_name);

        checking_name.setText("Checking Account ("+LoginActivity.client.getChecking_account().substring(LoginActivity.client.getChecking_account().length() - 4)+")");
        saving_name.setText("Savings Account ("+LoginActivity.client.getSaving_account().substring(LoginActivity.client.getSaving_account().length() - 4)+")");
        credit_name.setText("Credit Account ("+LoginActivity.client.getCredit_account().substring(LoginActivity.client.getCredit_account().length() - 4)+")");

        homename = v.findViewById(R.id.homename);
        checking = v.findViewById(R.id.checking_balance);
        saving = v.findViewById(R.id.saving_balance);
        credit = v.findViewById(R.id.credit_balance);
        tv_total = v.findViewById(R.id.tv_total);

        tv_checking =  v.findViewById(R.id.tv_checking);
        tv_saving = v.findViewById(R.id.tv_saving);
        tv_credit = v.findViewById(R.id.tv_credit);

        tv_checking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), CheckingActivity.class);
                startActivity(i);
            }
        });
        tv_saving.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), SavingActivity.class);
                startActivity(i);
            }
        });
        tv_credit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), CreditActivity.class);
                startActivity(i);
            }
        });


        return  v;
    }

    @Override
    public void onResume() {
        super.onResume();

        homename.setText("WELCOME! "+ LoginActivity.client.getName());
        checking.setText("$"+decimalFormat(LoginActivity.client.getChecking_balance()));
        saving.setText("$"+decimalFormat(LoginActivity.client.getSaving_balance()));
        credit.setText("$"+decimalFormat(LoginActivity.client.getCredit_balance()));
        tv_total.setText("$"+ decimalFormat(LoginActivity.client.getChecking_balance() + LoginActivity.client.getSaving_balance()));
    }

    public double decimalFormat(double dd){
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.FLOOR);
        double result = Double.parseDouble(df.format(dd));
        return result;
    }


}