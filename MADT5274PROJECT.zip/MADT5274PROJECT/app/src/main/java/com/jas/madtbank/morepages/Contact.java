package com.jas.madtbank.morepages;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.jas.madtbank.R;

public class Contact extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        final TextView GQ1 = findViewById(R.id.GQ1);
        final TextView GQ2 = findViewById(R.id.GQ2);
        final TextView CC1 = findViewById(R.id.CC1);
        final TextView CC2 = findViewById(R.id.CC2);

        GQ1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                goToDialer(GQ1.getText().toString());
            }
        });

        GQ2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                goToDialer(GQ2.getText().toString());
            }
        });

        CC1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                goToDialer(CC1.getText().toString());
            }
        });

        CC2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                goToDialer(CC2.getText().toString());
            }
        });


    }

    public void goToDialer(String phoneNumber){

        if (Build.VERSION.SDK_INT > 22) {

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 101);
                return;
            }
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:+" + phoneNumber.trim()));
            startActivity(callIntent);
        } else {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:+" + phoneNumber.trim()));
            startActivity(callIntent);
        }

    }

    public void gotitC(View v){
        finish();
    }
}
