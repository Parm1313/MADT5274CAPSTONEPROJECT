package com.jas.madtbank.activities;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricPrompt;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jas.madtbank.R;
import com.jas.madtbank.user.Client;

import java.util.concurrent.Executor;

public class LoginActivity extends AppCompatActivity {

    public static String TAG = "JAS";
    Button btn_login,btn_login_finger;

    EditText et_cardno,et_password;

    static public FirebaseDatabase database ;
    static public DatabaseReference myRef;

    static public Client client;

    static public SharedPreferences sp;

    private Executor executor;
    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo promptInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sp = PreferenceManager.getDefaultSharedPreferences(getBaseContext());

        executor = ContextCompat.getMainExecutor(this);
        biometricPrompt = new BiometricPrompt(LoginActivity.this,
                executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode,
                                              @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                Toast.makeText(getApplicationContext(),
                        "Authentication error: " + errString, Toast.LENGTH_SHORT)
                        .show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(getApplicationContext(), "Authentication failed",
                        Toast.LENGTH_SHORT)
                        .show();
            }


            @Override
            public void onAuthenticationSucceeded(
                    @NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(getApplicationContext(),
                        "Authentication succeeded!", Toast.LENGTH_SHORT).show();

                // add code here
                login(false);
            }

        });

        promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Biometric login")
                .setSubtitle("Log in using your biometric credential")
                .setNegativeButtonText("Use account password")
                .build();

        et_cardno = findViewById(R.id.et_cardno);
        et_password = findViewById(R.id.et_password);

        btn_login_finger = findViewById(R.id.btn_login_finger);
        btn_login_finger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(sp.getBoolean("fingerprint",false)){

                    if(et_cardno.getText().toString().equals("")){
                        Toast.makeText(LoginActivity.this, "Enter the Card Number!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    biometricPrompt.authenticate(promptInfo);

                }else{
                    Toast.makeText(LoginActivity.this, "Fingerprint is not enabled in App's settings, Use password!", Toast.LENGTH_SHORT).show();
                }

            }

        });

        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(et_cardno.getText().toString().equals("")){
                    Toast.makeText(LoginActivity.this, "Enter the Card Number!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(et_password.getText().toString().equals("")){
                    Toast.makeText(LoginActivity.this, "Enter the Password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                login(true);

            }

        });

    }

    public void login(final boolean passwordRequired){

        // Write a message to the database
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("cards");

        // get values
        // myRef = myRef.child(et_cardno.getText().toString());

        // set values
        // myRef.child("1234567890123456").child("saving_transactions").child("10-12-2019--10:10AM").setValue("50,db");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                boolean flag = false;

                for(DataSnapshot postSnapshot: dataSnapshot.getChildren()){


                    String account = postSnapshot.getKey();
                    Log.d(TAG, "Account is: " + account);

                    String[] separated = account.split(",");
                    String cardno = separated[0];
                    Log.d(TAG, "Card is: " + cardno);

                    if(cardno.equals(et_cardno.getText().toString())){
                        flag = true;
                        myRef = myRef.child(account);

                        String value = dataSnapshot.child(account).child("password").getValue(String.class);
                        Log.d(TAG, "Password is: " + value);

                        String et_pass = et_password.getText().toString();

                        if(passwordRequired && et_pass.equals(value) || !passwordRequired){

                            // everything is OK
                            String name = dataSnapshot.child(account).child("name").getValue(String.class);
                            String dob = dataSnapshot.child(account).child("dob").getValue(String.class);
                            String gender = dataSnapshot.child(account).child("gender").getValue(String.class);
                            String email = dataSnapshot.child(account).child("email").getValue(String.class);
                            Long phone = dataSnapshot.child(account).child("phone").getValue(long.class);
                            String address = dataSnapshot.child(account).child("address").getValue(String.class);

                            String checking_account = separated[1];
                            String saving_account = separated[2];
                            String credit_account = separated[3];

                            Double checking_balance = dataSnapshot.child(account).child("checking_balance").getValue(double.class);
                            Double saving_balance = dataSnapshot.child(account).child("saving_balance").getValue(double.class);

                            Double credit_balance = dataSnapshot.child(account).child("credit_balance").getValue(double.class);
                            Double credit_limit = dataSnapshot.child(account).child("credit_limit").getValue(double.class);

                            String checking_transactions = dataSnapshot.child(account).child("checking_transactions").getValue(String.class);
                            String saving_transactions = dataSnapshot.child(account).child("saving_transactions").getValue(String.class);
                            String credit_transactions = dataSnapshot.child(account).child("credit_transactions").getValue(String.class);

                            String credit_statement = dataSnapshot.child(account).child("credit_statement").getValue(String.class);

                            client = new Client(account,name,dob,gender,email,phone,address,checking_account,saving_account,checking_transactions,saving_transactions,checking_balance,saving_balance,credit_account,credit_transactions,credit_balance,credit_limit,credit_statement,value);

                            Intent i = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(i);

                            et_cardno.setText("");
                            et_password.setText("");

                        }else{
                            showalert(LoginActivity.this,"Error","Password is wrong!");
                        }

                        break;
                    }
                }

                if(!flag){
                    showalert(LoginActivity.this,"Error","Account does not exist!");
                }

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });

    }

    public static void showalert(Context c, String title, String message){

        new AlertDialog.Builder(c)
                .setTitle(title)
                .setMessage(message)

//                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // Continue with delete operation
//                    }
//                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.ok, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();

    }

    public static void sendNotification(Context c,String title,String message){

        NotificationManager notificationManager = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        String NOTIFICATION_CHANNEL_ID = "MADT_BANK";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "MADT BANK", NotificationManager.IMPORTANCE_HIGH);
            // Configure the notification channel.
            notificationChannel.setDescription("Channel description");
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationChannel.enableVibration(true);
            notificationManager.createNotificationChannel(notificationChannel);
        }

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(c, NOTIFICATION_CHANNEL_ID)

                .setAutoCancel(false)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setTicker(message)
                .setContentText(message)
                .setContentInfo("Info");

        notificationManager.notify(/*notification id*/1, notificationBuilder.build());

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        System.exit(0);
    }
}
