package com.jas.madtbank.activities;

import android.os.Bundle;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.jas.madtbank.R;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Locale;

public class CheckingActivity extends AppCompatActivity {

    ArrayList<String> allTrans = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checking);

        TextView checking_bal = findViewById(R.id.checking_bal);
        TextView checking_acc = findViewById(R.id.checking_acc);

        checking_bal.setText("$"+decimalFormat(LoginActivity.client.getChecking_balance()));
        checking_acc.setText(LoginActivity.client.getChecking_account());

        final TextView checking_trans = findViewById(R.id.checking_trans);
        final String trans = LoginActivity.client.getChecking_transactions();
        checking_trans.setText(trans.replaceAll("%","\n\n"));

        String[] separated = trans.split("%");

        for(int i=0;i < separated.length;i++){
            allTrans.add(separated[i]);
        }

        SearchView searchView = findViewById(R.id.searchview);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                String data = "";

                for(int i =0; i< allTrans.size();i++){
                    if(allTrans.get(i).toLowerCase(Locale.CANADA).contains(newText.toLowerCase(Locale.CANADA))){
                        data = data +"\n\n" + allTrans.get(i);
                    }
                }

                if(newText.equals("")){
                    data = trans.replaceAll("%","\n\n");
                }
                checking_trans.setText(data);
                return true;
            }
        });

    }

    public double decimalFormat(double dd){
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.FLOOR);
        double result = Double.parseDouble(df.format(dd));
        return result;
    }
}
