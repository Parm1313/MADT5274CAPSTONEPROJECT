package com.jas.madtbank.user;

public class ClientOther {

    private String fullacc,checking_account,saving_account,checking_transactions,saving_transactions;
    private double checking_balance,saving_balance;

    public ClientOther(String fullacc1, String checking_account1, String saving_account1, String checking_transactions1, String saving_transactions1, double checking_balance1, double saving_balance1){
        fullacc = fullacc1;
        checking_account = checking_account1;
        saving_account = saving_account1;
        checking_transactions = checking_transactions1;
        saving_transactions = saving_transactions1;
        checking_balance = checking_balance1;
        saving_balance = saving_balance1;
    }

    public String getFullacc() {
        return fullacc;
    }

    public void setFullacc(String fullacc) {
        this.fullacc = fullacc;
    }

    public String getChecking_account() {
        return checking_account;
    }

    public void setChecking_account(String checking_account) {
        this.checking_account = checking_account;
    }

    public String getSaving_account() {
        return saving_account;
    }

    public void setSaving_account(String saving_account) {
        this.saving_account = saving_account;
    }

    public String getChecking_transactions() {
        return checking_transactions;
    }

    public void setChecking_transactions(String checking_transactions) {
        this.checking_transactions = checking_transactions;
    }

    public String getSaving_transactions() {
        return saving_transactions;
    }

    public void setSaving_transactions(String saving_transactions) {
        this.saving_transactions = saving_transactions;
    }

    public double getChecking_balance() {
        return checking_balance;
    }

    public void setChecking_balance(double checking_balance) {
        this.checking_balance = checking_balance;
    }

    public double getSaving_balance() {
        return saving_balance;
    }

    public void setSaving_balance(double saving_balance) {
        this.saving_balance = saving_balance;
    }


}

