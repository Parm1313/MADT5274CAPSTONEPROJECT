package com.jas.madtbank.morepages;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;

import com.jas.madtbank.R;

public class Fingerprint extends AppCompatActivity {

    Switch finger_switch;
    public SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fingerprint);

        sp = PreferenceManager.getDefaultSharedPreferences(getBaseContext());

        finger_switch = findViewById(R.id.finger_switch);

        if(sp.getBoolean("fingerprint",false)){
            finger_switch.setChecked(true);
        }else{
            finger_switch.setChecked(false);
        }

        finger_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked){
                    sp.edit().putBoolean("fingerprint",true).apply();
                }else{
                    sp.edit().putBoolean("fingerprint",false).apply();
                }
            }
        });

        BiometricManager biometricManager = BiometricManager.from(this);
        switch (biometricManager.canAuthenticate()) {
            case BiometricManager.BIOMETRIC_SUCCESS:
                finger_switch.setClickable(true);
                Log.d("MY_APP_TAG", "App can authenticate using biometrics.");
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                finger_switch.setClickable(false);
                Toast.makeText(this, "No Hardware available for biometrics, you can't use this feature!", Toast.LENGTH_SHORT).show();
                Log.e("MY_APP_TAG", "No biometric features available on this device.");
                break;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                finger_switch.setClickable(false);
                Toast.makeText(this, "Hardware unavailable for biometrics, you can't use this feature!", Toast.LENGTH_SHORT).show();
                Log.e("MY_APP_TAG", "Biometric features are currently unavailable.");
                break;
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                finger_switch.setClickable(false);
                Toast.makeText(this, "Please add biometrics in your device settings to use this feature!", Toast.LENGTH_SHORT).show();
                Log.e("MY_APP_TAG", "The user hasn't associated " +
                        "any biometric credentials with their account.");
                break;
        }
    }

    public void gotitF(View v){
        finish();
    }
}
